package com.fmr.exceptions;

public class NegativeAmountException extends RuntimeException{
    public double getWithdrawAmt() {
        return withdrawAmt;
    }

    public void setWithdrawAmt(double withdrawAmt) {
        this.withdrawAmt = withdrawAmt;
    }

    private double withdrawAmt;

    public NegativeAmountException() {
    }

    public NegativeAmountException(String message) {
        super(message);
    }

    public NegativeAmountException(String message, double amount) {
        super(message);
        this.withdrawAmt = amount;

    }
    public NegativeAmountException(String message, Throwable cause) {
        super(message, cause);
    }

    public NegativeAmountException(Throwable cause) {
        super(cause);
    }

    public NegativeAmountException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
