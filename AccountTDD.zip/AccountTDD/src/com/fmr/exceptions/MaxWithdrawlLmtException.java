package com.fmr.exceptions;

public class MaxWithdrawlLmtException extends RuntimeException {

    public MaxWithdrawlLmtException() {
    }

    public MaxWithdrawlLmtException(String message) {
        super(message);
    }

    public MaxWithdrawlLmtException(String message, Throwable cause) {
        super(message, cause);
    }

    public MaxWithdrawlLmtException(Throwable cause) {
        super(cause);
    }

    public MaxWithdrawlLmtException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
