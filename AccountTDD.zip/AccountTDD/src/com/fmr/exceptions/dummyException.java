package com.fmr.exceptions;

public class dummyException extends RuntimeException {
    public dummyException() {
    }

    public dummyException(String message) {
        super(message);
    }

    public dummyException(String message, Throwable cause) {
        super(message, cause);
    }

    public dummyException(Throwable cause) {
        super(cause);
    }

    public dummyException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
