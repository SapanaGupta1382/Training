package com.fmr.exceptions;

public class OverDrawException extends RuntimeException {
    public OverDrawException() {
    }

    public OverDrawException(String message) {
        super(message);
    }

    public OverDrawException(String message, Throwable cause) {
        super(message, cause);
    }

    public OverDrawException(Throwable cause) {
        super(cause);
    }

    public OverDrawException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
