package com.fmr;

import com.fmr.exceptions.InvalidAmountException;
import com.fmr.exceptions.NegativeAmountException;
import com.fmr.exceptions.OverDrawException;

public class SavingAccount extends Account {

    public SavingAccount(double balance) {
        super(balance);
    }

    @Override
    public void withdraw(double amount) {
        double withdrawFee = calculateFee(amount);
        double adjustedAmt = getAdjustedAmt(amount, withdrawFee);
        super.withdraw(adjustedAmt);
        this.setTransactionFee(this.getTransactionFee() + withdrawFee);
    }

    private double getAdjustedAmt(double amount, double withdrawFee) {
        return amount + withdrawFee;
    }

    private double calculateFee(double amount) {
       return Math.ceil((amount*0.02>1)?(amount*0.02):1.0);
    }
}
