package com.fmr;

public class CheckingAccount extends Account {
    public CheckingAccount(double initBalance){
        super(initBalance);
    }
}
