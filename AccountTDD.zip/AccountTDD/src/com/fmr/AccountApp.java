package com.fmr;

import com.fmr.exceptions.InvalidAmountException;
import com.fmr.exceptions.MaxWithdrawlLmtException;
import com.fmr.exceptions.NegativeAmountException;
import com.fmr.exceptions.OverDrawException;

public class AccountApp {
    public static void main(String[] args) {
        System.out.println("Account Initializing.....");
        Account account = new SavingAccount(2000);
        Account account1 = new OverDraftAccount(200);
        System.out.println("Balance is: " + account.getBalance());

        account.deposite(500);
        System.out.println("Balance is: " + account.getBalance());
        account.withdraw(100);
        System.out.println("Balance is: " + account.getBalance());

        try {


            account.withdraw(200);
            //account1.withdraw(900);
            System.out.println("collected fee: " + account.getCollectedFees());
        }
        catch(InvalidAmountException e){
            System.out.println("An error occured :" + e.getMessage());

        }
        catch(OverDrawException e1){

            System.out.println("An error occured :" + e1.getMessage());
        }
        catch(MaxWithdrawlLmtException e2){
            System.out.println("An error occured : " + e2.getMessage());
        }
        catch(NegativeAmountException e3){
            System.out.println("An error occured : " + e3.getMessage());
        }

    }
}
