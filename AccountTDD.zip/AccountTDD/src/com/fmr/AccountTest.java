package com.fmr;


import com.fmr.exceptions.InvalidAmountException;
import com.fmr.exceptions.MaxWithdrawlLmtException;
import com.fmr.exceptions.NegativeAmountException;
import com.fmr.exceptions.OverDrawException;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class AccountTest {

    @Test
    public void checkInitBalanceIsZero(){
        Account account = new Account();
        assertEquals(0.0,account.getBalance(),0.0001);

    }

    @Test(expected = IllegalArgumentException.class)
    public void initialBalanceNotNegative(){
        new Account(-100);
    }

    @Test
    public void depositePositiveAmount(){
        double initBal = 2000;
        double depositeAmt = 1000;
        Account account = new Account(initBal);
        account.deposite(depositeAmt);
        assertEquals(initBal+depositeAmt, account.getBalance(),0.0001);
    }

    @Test(expected = NegativeAmountException.class)
    public void depositeNegativeAmountSavingAcc(){
        double initBal = 2000;
        double depositeAmt = -1000;
        Account account = new SavingAccount(initBal);
        account.deposite(depositeAmt);
        //("Amount can't be zero or less: " + depositeAmt, exception().getMessage());
    }

    @Test(expected = NegativeAmountException.class)
    public void depositeNegativeAmountOverDraft(){
        double initBal = 2000;
        double depositeAmt = -1000;
        Account account = new OverDraftAccount(initBal);
        account.deposite(depositeAmt);
        //("Amount can't be zero or less: " + depositeAmt, exception().getMessage());
    }

    @Test(expected = InvalidAmountException.class)
    public void depositeNegativeAmount1() {
        double initBal = 2000;
        double depositeAmt = -1000;
        Account account = new Account(initBal);
        try {
            account.deposite(depositeAmt);
        } catch (InvalidAmountException e) {
            String message = "Amount can't be zero or less: " + depositeAmt;
            assertEquals(message, e.getMessage());
            throw e;
        }
        fail("Negative deposite amount exception did not throw!");
    }

    @Test
    public void withdrawValidAmount(){
        double initBal = 2000;
        double withdrawAmt = 1000;
        Account account = new Account(initBal);
        account.withdraw(withdrawAmt);
        assertEquals(initBal-withdrawAmt, account.getBalance(),0.0001);
    }

    //@Test
    public void withdrawOverLimit() {
        fail("implement me");
    }

    @Test
    public void withdrawSavingAccount(){
        double initBal = 2000;
        double withdrawAmt = 1000;
        int transFee = 20;//(withdrawAmt*0.02>1)? (int) (withdrawAmt * 0.02) :1;
        Account account = new SavingAccount(initBal);
        account.withdraw(withdrawAmt);
        assertEquals(initBal-(withdrawAmt+transFee), account.getBalance(),0.0001);
        assertEquals(transFee,account.getTransactionFee(),0.0001);
    }

    @Test(expected = NegativeAmountException.class)
    public void withdrawNegativeAmtSavingAccount(){
        double initBal = 2000;
        double withdrawAmt = -900;
        //int transFee = (withdrawAmt*0.02>1)? (int) (withdrawAmt * 0.02) :1;
        Account account = new SavingAccount(initBal);
        account.withdraw(withdrawAmt);
    }

    @Test(expected = OverDrawException.class)
    public void overDrawAmtSavingAccount(){
        double initBal = 500;
        double withdrawAmt = 900;
        int transFee = (withdrawAmt*0.02>1)? (int) (withdrawAmt * 0.02) :1;
        Account account = new SavingAccount(initBal);
        account.withdraw(withdrawAmt);
    }

    @Test(expected = MaxWithdrawlLmtException.class)
    public void withdrawMoreThanWithdrawLimitfromSaving(){
        double initBal = 2000;
        double withdrawAmt = 1500;
        //int transFee = (withdrawAmt*0.02>1)? (int) (withdrawAmt * 0.02) :1;
        Account account = new SavingAccount(initBal);
        account.withdraw(withdrawAmt);

    }

    @Test
    public void withdrawValidAmtOverDraftAccount(){
        double initBal = 2000;
        double withdrawAmt = 500;
        Account account = new OverDraftAccount(initBal);
        account.withdraw(withdrawAmt);
        assertEquals(initBal-withdrawAmt, account.getBalance(),0.0001);
    }
    @Test(expected = NegativeAmountException.class)
    public void withdrawNegativeAmtOverDraftAccount(){
        double initBal = 2000;
        double withdrawAmt = -900;
        Account account = new OverDraftAccount(initBal);
        account.withdraw(withdrawAmt);
    }

    @Test(expected = OverDrawException.class)
    public void overDrawAmtOverDraftAccount(){
        double initBal = 300;
        double withdrawAmt = 1000;
        Account account = new OverDraftAccount(initBal);
        account.withdraw(withdrawAmt);
    }

    @Test
    public void overDrawAmt500OverDraftAccount(){
        double initBal = 2000;
        double withdrawAmt = 2500;
        Account account = new OverDraftAccount(initBal);
        account.withdraw(withdrawAmt);
        assertEquals(initBal-(withdrawAmt), account.getBalance(),0.0001);

    }
    @Test(expected = MaxWithdrawlLmtException.class)
    public void withdrawMoreThanWithdrawLimitfromOverDraft(){
        double initBal = 2000;
        double withdrawAmt = 1500;
        //int transFee = (withdrawAmt*0.02>1)? (int) (withdrawAmt * 0.02) :1;
        Account account = new OverDraftAccount(initBal);
        account.withdraw(withdrawAmt);

    }


}
