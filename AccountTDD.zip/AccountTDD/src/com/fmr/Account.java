package com.fmr;

import com.fmr.exceptions.InvalidAmountException;
import com.fmr.exceptions.MaxWithdrawlLmtException;
import com.fmr.exceptions.NegativeAmountException;
import com.fmr.exceptions.OverDrawException;

public class Account {
    public static final double MAX_WITHDRAWL_LIMIT = 1000;

    private double balance = 0.0;

    private double transactionFee = 0;

    public double getTransactionFee() {
        return this.transactionFee;
    }

    public void setTransactionFee(double transactionFee) {
        this.transactionFee = transactionFee;
    }

    public Account() {}

    public Account(double balance) {
        assertInitialBalanceIsNotNegative(balance);
        this.balance = balance;
        this.transactionFee = transactionFee;
    }

    private void assertInitialBalanceIsNotNegative(double balance) {
        if (balance < 0) throw new IllegalArgumentException("Initial balance can't be negative.");
    }

    public double getBalance() {
        return this.balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public void deposite (double amount) {
        validateAmount(amount);
        this.balance += amount;

    }

    public void withdraw(double amount) {
        validateAmount(amount);
        validateMaxWithDrawl(amount);
        if (amount > this.balance) throw new OverDrawException("Can't withdraw more than current limit of :" +this.balance);

        this.balance -= amount;

    }

    public void validateAmount(double amount){
        if (amount<=0)  throw new NegativeAmountException("Amount can't be zero or less: " + amount);
    }

    public void validateMaxWithDrawl(double amount) {
        if (amount >  MAX_WITHDRAWL_LIMIT) throw new MaxWithdrawlLmtException("Cann't withdraw more than : " + MAX_WITHDRAWL_LIMIT);
    }

    public double getCollectedFees() {

        return transactionFee;

    }


    }
