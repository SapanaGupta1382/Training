package com.fmr;

import com.fmr.exceptions.InvalidAmountException;
import com.fmr.exceptions.NegativeAmountException;
import com.fmr.exceptions.OverDrawException;

public class OverDraftAccount extends Account {

    public static final int MAX_ALLOWED_NEG_BALANCE = 500;
    public OverDraftAccount(double balance) {
        super(balance);
    }

    @Override
    public void withdraw(double amount) {
        validateAmount(amount);
        validateMaxWithDrawl(amount);
        if (amount > this.getBalance()+ MAX_ALLOWED_NEG_BALANCE) throw new OverDrawException("Can't overdraw ");
        this.setBalance(this.getBalance()-amount);

    }
}
